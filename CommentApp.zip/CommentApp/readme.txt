Frameworks and softwares used:
1. Java 8
2. Spring
3. Mysql
4. HTML and thymeleaf

How to run
1. Run the mysql server and create database with name "commentapp"
2. Open as maven project in Intellij
3. Open CommentApp and modify application.properties file with db password for root, IP address if not localhost and port number.
3. Right click Main.java file and click "Run" option.
4. Open Browser with link "http://localhost:8080/"
