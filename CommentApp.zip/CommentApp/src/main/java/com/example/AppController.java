package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private CommentRepository commentRepo;
	
	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}
	
	@GetMapping("/signup")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		return "signup_form";
	}

	@GetMapping("/forgetpassword")
	public String forgetpassword(Model model) {
		model.addAttribute("forgetpassword", new ForgetPassword());
		return "forgetpassword";
	}


	@PostMapping("/process_forget_password")
	public String process_forget_password(ModelAndView model, ForgetPassword forgetPassword) {
		User user = userRepo.findByEmail(forgetPassword.getEmail());
		if(user == null){
			model.addObject("message","User not found");
		}
		else if(forgetPassword.getSecret().equals(user.getSecret())){
			user.setPassword(encodedPassword(forgetPassword.getNewpassword()));
			userRepo.save(user);
			return "redirect:/login";
		}else{
			model.addObject("message","Secret is wrong");
		}
		return "redirect:/error";
	}


	private String encodedPassword(String password){
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		return passwordEncoder.encode(password);
	}


	@PostMapping("/process_register")
	public String processRegister(ModelAndView model, User user) {
		User u = userRepo.findByEmail(user.getEmail());
		System.out.println(u);
		if(u == null) {
			user.setPassword(encodedPassword((user.getPassword())));
			userRepo.save(user);
			return "redirect:/login";
		}
		model.addObject("message","Email ID already registered");
		return "redirect:/error";
	}

	@GetMapping("/user/process_comments")
	public String processcomments( @RequestParam(name = "comment") String commentText) {
		Comment comment = new Comment();
		comment.setComment(commentText);
		comment.setEmail(getLoggedInEmail());
		commentRepo.save(comment);
		return "redirect:/user/comments";
	}
	private String getLoggedInEmail(){
		Object principal = SecurityContextHolder.getContext	().getAuthentication().getPrincipal();
		String email;
		if (principal instanceof UserDetails) {
			email = ((UserDetails)principal).getUsername();
		} else {
			email = principal.toString();
		}
		return email;
	}
	@GetMapping("/user/comments")
	public String listComments(Model model, @RequestParam(value = "filterbyemail",required = false) boolean isEnabled) {
		List<Comment> listUsers;
		model.addAttribute("comment", new Comment());
		if(isEnabled){
			 listUsers = commentRepo.findByEmail(getLoggedInEmail());
		}else{
			listUsers = commentRepo.findAll();
		}
		model.addAttribute("listComments", listUsers);
		return "Comments";
	}
}
